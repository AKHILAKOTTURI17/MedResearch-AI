# MedResearch AI

A starter scaffold for a Gemini-powered medical research assistant concept.

**Status:** This is not a completed or clinically validated application. Automatic literature retrieval and a frontend are not included yet.

## Intended idea
Help users explore medical literature, summarize supplied research notes, and keep source links visible for verification.

## Stack
- Python
- FastAPI
- Google Gemini API
- Pydantic

## Setup
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

Set your key securely as an environment variable:

Windows PowerShell:
```powershell
$env:GOOGLE_API_KEY="your-api-key"
uvicorn app.main:app --reload
```

macOS/Linux:
```bash
export GOOGLE_API_KEY="your-api-key"
uvicorn app.main:app --reload
```

Then open http://127.0.0.1:8000/docs.

## Endpoints
- `GET /health` — API health check
- `POST /research` — summarizes research notes supplied by the caller and returns the supplied source links

**Important:** `/research` does not fetch external studies. Only provide notes and sources you have checked. Do not commit API keys. Not for diagnosis or treatment; verify output against original papers and consult qualified healthcare professionals for personal medical decisions.
