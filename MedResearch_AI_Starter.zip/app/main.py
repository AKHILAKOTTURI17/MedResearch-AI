import os
from typing import List

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from google import genai

app = FastAPI(title="MedResearch AI API", version="0.1.0")


class Source(BaseModel):
    title: str = Field(..., min_length=1, max_length=300)
    url: str = Field(..., min_length=8, max_length=2000)


class ResearchRequest(BaseModel):
    question: str = Field(..., min_length=3, max_length=2000)
    research_notes: str = Field(..., min_length=20, max_length=20000)
    sources: List[Source] = Field(default_factory=list)


class ResearchResponse(BaseModel):
    summary: str
    sources: List[Source]
    disclaimer: str


@app.get("/health")
def health():
    return {"status": "ok", "project": "MedResearch AI", "version": "0.1.0"}


@app.post("/research", response_model=ResearchResponse)
def research(request: ResearchRequest):
    api_key = os.getenv("GOOGLE_API_KEY")
    if not api_key:
        raise HTTPException(status_code=503, detail="Set GOOGLE_API_KEY before using /research.")

    client = genai.Client(api_key=api_key)
    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    prompt = f"""
You are MedResearch AI, an educational medical literature summarizer.
Do not diagnose, prescribe, or recommend treatment. Use only the supplied notes.
Do not invent findings or citations. Mention limitations and uncertainty.
Question: {request.question}

Research notes:
{request.research_notes}
"""
    try:
        result = client.models.generate_content(model=model, contents=prompt)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Gemini request failed: {type(exc).__name__}") from exc

    summary = (getattr(result, "text", None) or "").strip()
    if not summary:
        raise HTTPException(status_code=502, detail="Gemini returned an empty response.")

    return ResearchResponse(
        summary=summary,
        sources=request.sources,
        disclaimer="For research and education only, not diagnosis or treatment. Verify all claims against original sources.",
    )
